#include <iostream>
#include <fstream>
#include <cmath>
#include "Map.h"
using namespace std;

int split(string str, char c, string array[], int size){
    if (str.length()== 0){
        return 0;
    }
    string word = "";
    int j = 0;
    str = str + c;
    for (int i = 0; i<str.length(); i++){
        if (str[i]==c){
            if (word.length() == 0) {
                continue;
            }
            array[j++]= word;
            word = "";
        }
        else {
            word = word + str[i];
        }
        
    }
    return j;
}


Map:: Map(){
    mapChar = "";
    playerIndex1 = 0;
    playerIndex2 = 0;
    
    ifstream inFile;
    inFile.open("mapPoke.txt");
    string line = "";
    string arr[16];
    int i = 0;
    while(getline(inFile, line)){
        split(line, ',', arr, 16);
        for(int j = 0; j<16;j++){
            map[i][j] = arr[j];
        }
        i++;
    }
}

string Map:: getMapTile(int index1, int index2){ // use this to determine what's at the input tile index 
    mapChar = map[index1][index2];    
    return mapChar;
}

void Map:: setTrainersName(){
    ifstream inFile;
    inFile.open("trainers.txt");
    string line = "";
    int i = 0;
    while(getline(inFile,line)){
        trainers[i].setTrainerName(line);
                i++;

    }
}

void Map:: playerStart(int chosenPoke){// the input will be 1-4 based on whichever pokemon is chosen by the player in the very start
    if(chosenPoke == 1){
        playerIndex1 = 13;
        playerIndex2 = 7;
    }
    if (chosenPoke == 2){
        playerIndex1 = 13;
        playerIndex2 = 8;
    }
    if (chosenPoke == 3){
        playerIndex1 = 13;
        playerIndex2 = 9;
    }
    if(chosenPoke == 4){
        playerIndex1 = 13;
        playerIndex2 = 10;
    }
}

void Map:: getPlayerLocation(){
    map[playerIndex1][playerIndex2] = "P1"; 
    if(playerIndex1>=3 && playerIndex1<=21 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< endl;     
    }
    if(playerIndex1 == 2 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+4][playerIndex2-3]<< " , " << map[playerIndex1+4][playerIndex2-2]<< " , " << map[playerIndex1+4][playerIndex2-1]<< " , " << map[playerIndex1+4][playerIndex2]<< " , " << map[playerIndex1+4][playerIndex2+1]<< " , " << map[playerIndex1+4][playerIndex2+2]<< " , " << map[playerIndex1+4][playerIndex2+3]<< endl;     

    }
    if(playerIndex1 == 1 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< endl;
        cout << map[playerIndex1+4][playerIndex2-3]<< " , " << map[playerIndex1+4][playerIndex2-2]<< " , " << map[playerIndex1+4][playerIndex2-1]<< " , " << map[playerIndex1+4][playerIndex2]<< " , " << map[playerIndex1+4][playerIndex2+1]<< " , " << map[playerIndex1+4][playerIndex2+2]<< " , " << map[playerIndex1+4][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+5][playerIndex2-3]<< " , " << map[playerIndex1+5][playerIndex2-2]<< " , " << map[playerIndex1+5][playerIndex2-1]<< " , " << map[playerIndex1+5][playerIndex2]<< " , " << map[playerIndex1+5][playerIndex2+1]<< " , " << map[playerIndex1+5][playerIndex2+2]<< " , " << map[playerIndex1+5][playerIndex2+3]<< endl;     

    }
    if(playerIndex1 == 0 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< endl;
        cout << map[playerIndex1+4][playerIndex2-3]<< " , " << map[playerIndex1+4][playerIndex2-2]<< " , " << map[playerIndex1+4][playerIndex2-1]<< " , " << map[playerIndex1+4][playerIndex2]<< " , " << map[playerIndex1+4][playerIndex2+1]<< " , " << map[playerIndex1+4][playerIndex2+2]<< " , " << map[playerIndex1+4][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+5][playerIndex2-3]<< " , " << map[playerIndex1+5][playerIndex2-2]<< " , " << map[playerIndex1+5][playerIndex2-1]<< " , " << map[playerIndex1+5][playerIndex2]<< " , " << map[playerIndex1+5][playerIndex2+1]<< " , " << map[playerIndex1+5][playerIndex2+2]<< " , " << map[playerIndex1+5][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+6][playerIndex2-3]<< " , " << map[playerIndex1+6][playerIndex2-2]<< " , " << map[playerIndex1+6][playerIndex2-1]<< " , " << map[playerIndex1+6][playerIndex2]<< " , " << map[playerIndex1+6][playerIndex2+1]<< " , " << map[playerIndex1+6][playerIndex2+2]<< " , " << map[playerIndex1+6][playerIndex2+3]<< endl;     
    
        
    }
    if(playerIndex1 == 22 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-4][playerIndex2-3]<< " , " << map[playerIndex1-4][playerIndex2-2]<< " , " << map[playerIndex1-4][playerIndex2-1]<< " , " << map[playerIndex1-4][playerIndex2]<< " , " << map[playerIndex1-4][playerIndex2+1]<< " , " << map[playerIndex1-4][playerIndex2+2]<< " , " << map[playerIndex1-4][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< endl;     

    }
    if(playerIndex1 == 23 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-5][playerIndex2-3]<< " , " << map[playerIndex1-5][playerIndex2-2]<< " , " << map[playerIndex1-5][playerIndex2-1]<< " , " << map[playerIndex1-5][playerIndex2]<< " , " << map[playerIndex1-5][playerIndex2+1]<< " , " << map[playerIndex1-5][playerIndex2+2]<< " , " << map[playerIndex1-5][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-4][playerIndex2-3]<< " , " << map[playerIndex1-4][playerIndex2-2]<< " , " << map[playerIndex1-4][playerIndex2-1]<< " , " << map[playerIndex1-4][playerIndex2]<< " , " << map[playerIndex1-4][playerIndex2+1]<< " , " << map[playerIndex1-4][playerIndex2+2]<< " , " << map[playerIndex1-4][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
        cout << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< endl;     
    }
    if(playerIndex1 == 24 && playerIndex2>=3 && playerIndex2<=12){
        cout << map[playerIndex1-6][playerIndex2-3]<< " , " << map[playerIndex1-6][playerIndex2-2]<< " , " << map[playerIndex1-6][playerIndex2-1]<< " , " << map[playerIndex1-6][playerIndex2]<< " , " << map[playerIndex1-6][playerIndex2+1]<< " , " << map[playerIndex1-6][playerIndex2+2]<< " , " << map[playerIndex1-6][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-5][playerIndex2-3]<< " , " << map[playerIndex1-5][playerIndex2-2]<< " , " << map[playerIndex1-5][playerIndex2-1]<< " , " << map[playerIndex1-5][playerIndex2]<< " , " << map[playerIndex1-5][playerIndex2+1]<< " , " << map[playerIndex1-5][playerIndex2+2]<< " , " << map[playerIndex1-5][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-4][playerIndex2-3]<< " , " << map[playerIndex1-4][playerIndex2-2]<< " , " << map[playerIndex1-4][playerIndex2-1]<< " , " << map[playerIndex1-4][playerIndex2]<< " , " << map[playerIndex1-4][playerIndex2+1]<< " , " << map[playerIndex1-4][playerIndex2+2]<< " , " << map[playerIndex1-4][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< endl;     
        cout << map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< endl;     
        cout << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< endl;  
    }
    if(playerIndex2 == 2 && playerIndex1>=3 && playerIndex1<=21){
        cout <<  map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     
        cout <<  map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     
        cout <<  map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     
        cout <<  map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;  
        cout <<  map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     
        cout <<  map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     
        cout <<  map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< endl;     

    }
    if(playerIndex2 == 1 && playerIndex1>=3 && playerIndex1<=21){
        cout <<   map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        cout <<   map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        cout <<   map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        cout <<   map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;  
        cout <<   map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        cout <<   map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        cout <<   map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;     
        
    }
    if(playerIndex2 == 0 && playerIndex1>=3 && playerIndex1<=21){
        cout <<    map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< " , " << map[playerIndex1-3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        cout <<    map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< " , " << map[playerIndex1-2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        cout <<    map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< " , " << map[playerIndex1-1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        cout <<    map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< " , " << map[playerIndex1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< endl;  
        cout <<    map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< " , " << map[playerIndex1+1][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        cout <<    map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< " , " << map[playerIndex1+2][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        cout <<    map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< " , " << map[playerIndex1+3][playerIndex2+3]<< " , "<< map[playerIndex1-3][playerIndex2+4]<< " , "<< map[playerIndex1-3][playerIndex2+5]<< " , "<< map[playerIndex1-3][playerIndex2+6]<< endl;     
        
    }
    if(playerIndex2 == 13 && playerIndex1>=3 && playerIndex1<=21){
        cout << map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< " , " << map[playerIndex1-3][playerIndex2+2]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< " , " << map[playerIndex1-2][playerIndex2+2]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< " , " << map[playerIndex1-1][playerIndex2+2]<< endl;     
        cout <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< " , " << map[playerIndex1][playerIndex2+2]<< endl;  
        cout <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< " , " << map[playerIndex1+1][playerIndex2+2]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< " , " << map[playerIndex1+2][playerIndex2+2]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< " , " << map[playerIndex1+3][playerIndex2+2]<< endl;     
        
    }
    if(playerIndex2 == 14 && playerIndex1>=3 && playerIndex1<=21){
        cout <<  map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< endl;     
        cout <<map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< endl;  
        cout <<map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< endl;     
        
    }
    if(playerIndex2 == 15 && playerIndex1>=3 && playerIndex1<=21){
        cout << map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1-3][playerIndex2-3]<< " , " << map[playerIndex1-3][playerIndex2-2]<< " , " << map[playerIndex1-3][playerIndex2-1]<< " , " << map[playerIndex1-3][playerIndex2]<< " , " << map[playerIndex1-3][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-2][playerIndex2-3]<< " , " << map[playerIndex1-2][playerIndex2-2]<< " , " << map[playerIndex1-2][playerIndex2-1]<< " , " << map[playerIndex1-2][playerIndex2]<< " , " << map[playerIndex1-2][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1-1][playerIndex2-3]<< " , " << map[playerIndex1-1][playerIndex2-2]<< " , " << map[playerIndex1-1][playerIndex2-1]<< " , " << map[playerIndex1-1][playerIndex2]<< " , " << map[playerIndex1-1][playerIndex2+1]<< endl;     
        cout <<map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1][playerIndex2-3]<< " , " << map[playerIndex1][playerIndex2-2]<< " , " << map[playerIndex1][playerIndex2-1]<< " , " << map[playerIndex1][playerIndex2]<< " , " << map[playerIndex1][playerIndex2+1]<< endl;  
        cout <<map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " << map[playerIndex1+1][playerIndex2-3]<< " , " << map[playerIndex1+1][playerIndex2-2]<< " , " << map[playerIndex1+1][playerIndex2-1]<< " , " << map[playerIndex1+1][playerIndex2]<< " , " << map[playerIndex1+1][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+2][playerIndex2-3]<< " , " << map[playerIndex1+2][playerIndex2-2]<< " , " << map[playerIndex1+2][playerIndex2-1]<< " , " << map[playerIndex1+2][playerIndex2]<< " , " << map[playerIndex1+2][playerIndex2+1]<< endl;     
        cout << map[playerIndex1-3][playerIndex2-6]<< " , " << map[playerIndex1-3][playerIndex2-5]<< " , " <<map[playerIndex1-3][playerIndex2-4]<< " , " <<map[playerIndex1+3][playerIndex2-3]<< " , " << map[playerIndex1+3][playerIndex2-2]<< " , " << map[playerIndex1+3][playerIndex2-1]<< " , " << map[playerIndex1+3][playerIndex2]<< " , " << map[playerIndex1+3][playerIndex2+1]<< endl;     
        
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 13){
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 2 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 1 && playerIndex2 == 13){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 0 && playerIndex2 == 13){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 2){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 1){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 0){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 13){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 22 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 23 && playerIndex2 == 13){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 15){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 14){
        
    }
    if(playerIndex1 == 24 && playerIndex2 == 13){
        
    }

    

    

    
    
    


}// this is my function that handles printing out the 7x7 map at each turn 

void Map:: setPlayerLocation(int ){// this function will move the player based on an input of 1-4 which in the game will be NSEW
    
}

void Map:: randomPokeStart(){// this will randomly place my 20 pokemon in the beginning of the game
    
}
