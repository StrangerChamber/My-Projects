"""lab3 controller."""
# Copyright University of Colorado Boulder 2022
# CSCI 3302 "Introduction to Robotics" Lab 3 Base Code.

from controller import Robot, Motor
import math

# TODO: Fill out with correct values from Robot Spec Sheet (or inspect PROTO definition for the robot)
MAX_SPEED = 6.67 # [rad/s]
MAX_SPEED_MS = 0.22 # [m/s]
AXLE_LENGTH = 0.16 # [m]
WEEL_RADIUS = 0.066/2 # [m]



MOTOR_LEFT = 0 # Left wheel index
MOTOR_RIGHT = 1 # Right wheel index

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# The Turtlebot robot has two motors
part_names = ("left wheel motor", "right wheel motor")


# Set wheels to velocity control by setting target position to 'inf'
# You should not use target_pos for storing waypoints. Leave it unmodified and 
# use your own variable to store waypoints leading up to the goal
target_pos = ('inf', 'inf') 
robot_parts = []

for i in range(len(part_names)):
        robot_parts.append(robot.getDevice(part_names[i]))
        robot_parts[i].setPosition(float(target_pos[i]))

# Odometry
pose_x     = -8
pose_y     = -5
pose_theta = 0

# Rotational Motor Velocity [rad/s]
vL = 0
vR = 0

# TODO
# Create you state and goals (waypoints) variable here
# You have to MANUALLY figure out the waypoints, one sample is provided for you in the instructions
waypoints = [(-6, -5.5, 0), (-5.5, -5.5, math.pi*3/12), (-4, -4, .5), (-2.5, -2.75, .8), (-2, -1.5, 1.8)]
point = 0

while robot.step(timestep) != -1:
    if point < len(waypoints):
        #print(waypoints[point])
        goal_x = waypoints[point][0]
        goal_y = waypoints[point][1]
        goal_theta = waypoints[point][2]
    else:
        vL = 0.0
        vR = 0.0
            
    # STEP 2.1: Calculate error with respect to current and goal position  
    rho = math.sqrt((pose_x-goal_x)**2 + (pose_y-goal_y)**2)
    alpha = (math.atan2(goal_y-pose_y, goal_x-pose_x))-pose_theta
    mu = goal_theta-pose_theta
    #print(rho, alpha, mu)
    # STEP 2.2: Feedback Controller
    p1 = 1
    p2 = 1
    p3 = -.3
    dx = p1*rho
    dTheta = p2*alpha+p3*mu
    
    # STEP 1: Inverse Kinematics Equations (vL and vR as a function dX and dTheta)
    # Note that vL and vR in code is phi_l and phi_r on the slides/lecture
    vL = (dx-(dTheta/2))
    vR = (dx+(dTheta/2))
    
    
    # STEP 2.3: Proportional velocities
    if (abs(vL) > abs(vR)):
        x = MAX_SPEED/vL
    else:
        x = MAX_SPEED/vR    
     
    vL = x*vL # Left wheel velocity in rad/s
    vR = x*vR # Right wheel velocity in rad/s

    # STEP 2.4: Clamp wheel speeds
    if vL > MAX_SPEED:
        vL = MAX_SPEED
    if vL < -MAX_SPEED:
        vL = -MAX_SPEED
    if vR > MAX_SPEED:
        vR = MAX_SPEED
    if vR < -MAX_SPEED:
        vR = -MAX_SPEED
    
    if rho < 0.001:
        if mu < -math.pi/36:
            vL = MAX_SPEED
            vR = -MAX_SPEED
        elif mu > math.pi/36:
            vL = -MAX_SPEED
            vR = MAX_SPEED
        else:
            vL = 0.0
            vR = 0.0
            point = point+1 
    
    
    # TODO
    # Use Your Lab 2 Odometry code after these 2 comments. We will supply you with our code next week 
    # after the Lab 2 deadline but you free to use your own code if you are sure about its correctness
    
    # NOTE that the odometry should ONLY be a function of 
    # (vL, vR, MAX_SPEED, MAX_SPEED_MS, timestep, AXLE_LENGTH, pose_x, pose_y, pose_theta)
    # Odometry code. Don't change speeds (vL and vR) after this line
    """angle_radians = pose_theta
    sin_value = math.sin(angle_radians)
    cos_value = math.cos(angle_radians)
    linear_velocity = (vL+vR)/2
    linear_velocity = linear_velocity*MAX_SPEED_MS/MAX_SPEED
    angular_velocity = (vR-vL)*(MAX_SPEED_MS/MAX_SPEED)/(2*AXLE_LENGTH)
 
    deltX = linear_velocity * cos_value * (timestep/1000)
    deltY = linear_velocity * sin_value * (timestep/1000)
    deltTheta = angular_velocity * (timestep/1000)
 
    pose_x = pose_x + deltX
    pose_y = pose_y + deltY
    pose_theta = pose_theta + deltTheta
    #pose_theta = math.radians(pose_theta)
    """
    distL = vL/MAX_SPEED * MAX_SPEED_MS * timestep/1000.0

    distR = vR/MAX_SPEED * MAX_SPEED_MS * timestep/1000.0
    
    pose_x += (distL+distR) / 2.0 * math.cos(pose_theta)
    
    pose_y += (distL+distR) / 2.0 * math.sin(pose_theta)
    
    pose_theta += (distR-distL)/AXLE_LENGTH
    #print(pose_x, pose_y, pose_theta)
    

    ########## End Odometry Code ##################
    
    ########## Do not change ######################
    # Bound pose_theta between [-pi, 2pi+pi/2]
    # Important to not allow big fluctuations between timesteps (e.g., going from -pi to pi)
    if pose_theta > 6.28+3.14/2: pose_theta -= 6.28
    if pose_theta < -3.14: pose_theta += 6.28
    ###############################################

    # TODO
    # Set robot motors to the desired velocities
    robot_parts[MOTOR_LEFT].setVelocity(vL)
    robot_parts[MOTOR_RIGHT].setVelocity(vR)

    