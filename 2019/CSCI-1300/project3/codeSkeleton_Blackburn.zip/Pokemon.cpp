#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
#include "Pokemon.h"

int split(string str, char c, string array[], int size){
    if (str.length()== 0){
        return 0;
    }
    string word = "";
    int j = 0;
    str = str + c;
    for (int i = 0; i<str.length(); i++){
        if (str[i]==c){
            if (word.length() == 0) {
                continue;
            }
            array[j++]= word;
            word = "";
        }
        else {
            word = word + str[i];
        }
        
    }
    return j;
}

Pokemon:: Pokemon(){
    ifstream inFile;
    inFile.open("pokemon.txt");
    string line = "";
    string myarr[9];
    int i = 0;
    while(getline(inFile,line)){
        split(line, ',', myarr, 9);
        if(myarr[0]!= "#"){
            pokeName[i] = myarr[1];
            pokeType1[i] = myarr[7];
            if(myarr[8]!=""){
            pokeType2[i] = myarr[8];
            }
            else{
                pokeType2[i] = "";
            }
            myarr[8]="";
            i++;
        }
    }
}


string Pokemon:: getType(int index){
    if(pokeType2[index]== ""){
        return pokeType1[index];
    }
    else{
        string type1 = pokeType1[index];
        string type2 = pokeType2[index];
        string typeCombo = type1 + " and " + type2;
        return typeCombo;
    }
}

string Pokemon:: getPokeName(int index){
    return pokeName[index];
}


