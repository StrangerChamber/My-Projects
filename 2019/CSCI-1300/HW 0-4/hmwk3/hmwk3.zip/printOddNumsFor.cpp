#include <iostream>
#include <math.h>

using namespace std;

int printOddNumsFor(int max){

for (int number = 0;number<max;){

    cout<<number+1<< " " << endl;
    number = number+2;
}
}

int main (){

}