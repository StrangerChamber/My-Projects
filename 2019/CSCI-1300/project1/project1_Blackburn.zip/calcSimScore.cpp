#include <iostream>
#include <math.h>
using namespace std;
// CS1300 Fall 2019
// Author: Jack Blackburn
// Recitation: f19 – Lucas
// Project 1 - Problem 4 ...


double calcSimScore (string sequence1, string sequence2){
if (sequence1.length()!=sequence2.length()){
return 0 ;
}
else if (sequence1==""){
    return 0;
}


double similarity_score;
double hamming_distance = 0;
for (int i =0; i<= sequence1.length();i++){
if (sequence1[i]!=sequence2[i]){
    hamming_distance++;
    


}
similarity_score = (sequence1.length()-hamming_distance)/(double) sequence1.length();
}
return similarity_score;
}




int main(){
    cout << calcSimScore("rdr","rtr")<< endl;
   
}