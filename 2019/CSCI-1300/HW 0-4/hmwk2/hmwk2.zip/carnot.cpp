#include <iostream>
#include <math.h>
using namespace std; 


double carnot(int Tc, int Th){
    cin >> Tc >> Th;

     double cEfficiency = 1 -(Tc/(double)Th);

    
}



int main(){
    carnot(1,1);
}