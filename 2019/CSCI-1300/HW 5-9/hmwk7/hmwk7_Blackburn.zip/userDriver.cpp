#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
#include "User.h"
#include "User.cpp"
#include "Book.h"


// CS1300 Fall 2019
// Author: Jack Blackburn
// Recitation: Lucas Haynes
// Homework 7 - 1





int main(){      // my test cases for user.cpp and user.h
    User users[50];
    cout << users[1].getRatingAt(5)<< endl;
    cout<< users[2].getSize()<< endl;
}