#include <iostream>
using namespace std;
#include <math.h>

void sphereSurfaceArea(double radius){
        cin >> radius ;
       double surfaceArea = 4.0 * M_PI * pow(radius,2);
        cout << "surface area: " << surfaceArea << endl;
    }
    
    int main(){
        
    }