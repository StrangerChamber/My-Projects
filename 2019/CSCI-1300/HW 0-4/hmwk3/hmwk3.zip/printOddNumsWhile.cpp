#include <iostream>
#include <math.h>
using namespace std;


void printOddNumsWhile(int max){
  int number=0;
  while (number<max){
   cout << number+1 << " " << endl;
   number = number+2;
  }
 }
 

int main (){
    
}