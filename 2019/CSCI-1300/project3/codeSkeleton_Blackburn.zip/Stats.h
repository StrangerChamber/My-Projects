#ifndef STATS_H
#define STATS_H
#include <iostream>
#include <string>
using namespace std;


class Stats{
  private:
  int HP[151];  // health of pokemon
  int attack[151]; // strength of attacks
  int defense[151]; // resistance against attacks
  int max[151];    // max value of the attack and defense values
  int speed[151]; // speed of poke 

  public:
  Stats();
  int getHP(int);
  void setHP(int);
  int getAttack(int);
  void setAttack(int);
  int getDefense(int);
  void setDefense(int);
  int getMax(int);
  int getSpeed(int);
  void setSpeed(int);
  void rest();
};
#endif