#include <iostream>
#include <cmath>
using namespace std;


// CS1300 Fall 2019
// Author: Jack Blackburn
// Recitation: lucas Hayne
// Homework 4 - Problem 6


int split(string input, char delimiter, string piece[], int MaxAmountOfPieces){ 
int matches = 1;
string temp = "";
if (input == ""){                  // all of these if statements are edge case checks and finding the number of splits the input will have
    return 0;
}

if (input[0] == delimiter){
    matches--;
}
if (input[input.length()-1] == delimiter){
    matches--;
}
for (int i = 0; i<input.length();i++){           // more if statements finding the number of matches
if (input[i]== delimiter && input[i+1]==delimiter){
    matches--;
} 
if (input[i]== delimiter){
    matches++;
}
}
int l = 0;
for (int j=0; j<input.length(); j + piece[l].length()+1){     // this is a loop i made but couldnt get to work i don't know whats missing because in coderunner it would keep telling me about a time limit exceeding
    int l = 0;
    int k = 0;

    while(k<=j && j<input.length()){      // I thought for sure this would work but sadly it did not i spent about 4 hours on this 
        if (input[j]!=delimiter){
            temp+=input[j];
            j++;
        }
        if (input[j]==delimiter) {
            k+=j+1;
        }
    }
    piece[l]=temp;
    temp="";
    l++;

}

return matches;
}










int main(){
string piece[6];
    cout << split("one small step",' ', piece, 5) << endl << " should be 3 endl one endl small endl step" << endl;

}

















