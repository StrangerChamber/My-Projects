#include <iostream>
using namespace std;
 
void classGreeting(int classNumber){

cin>> classNumber;
 cout<< "Hello, CS " << classNumber << " World!" << endl;


}
int main(){
    
}