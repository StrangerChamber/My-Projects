#ifndef TRAINERS_H
#define TRAINERS_H
#include <iostream>
#include <string>
using namespace std;


class Trainers{
    private:
    string trainerName;
    string trainerGym;
    public:
    Trainers();
    Trainers(string, string);
    string getTrainerName();
    void setTrainerName(string);
    string getTrainerGym();
    void setTrainerGym(string);
    
    
};
#endif