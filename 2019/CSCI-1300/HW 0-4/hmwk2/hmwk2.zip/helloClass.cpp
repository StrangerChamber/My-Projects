#include <iostream>
using namespace std;



int main() {
    
int courseNumber;
cin >> courseNumber;
cout << "Enter a CS course number:" << endl << "Hello, CS " << courseNumber << " World!"<< endl;

}