#include <iostream>
#include <cmath>
#include <string>
using namespace std;
#include "planet.h"
#include "planet.cpp"


int main(){
    Planet planets[5];
planets[0] = Planet(“On A Cob Planet”,1234);
planets[1] = Planet(“Bird World”,4321);
int idx = maxRadius(planets, 2);
cout << planets[idx].getName() << endl;
cout << planets[idx].getRadius() << endl;
cout << planets[idx].getVolume() << endl;
}