#include <iostream>
#include <math.h>
using namespace std;


    void sphereVolume(double radius){
        cin >> radius ;
       double volume = (4.0/3.0) * M_PI * pow(radius,3);
        cout << "volume: " << volume << endl;
    }
    
    int main(){
        
    }