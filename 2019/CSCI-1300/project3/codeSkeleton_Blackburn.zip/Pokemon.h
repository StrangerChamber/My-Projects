#ifndef POKEMON_H
#define POKEMON_H
#include <iostream>
#include <string>
using namespace std;



class Pokemon
{
  private:
  string pokeType1[151];
  string pokeType2[151];
  string pokeName[151];
  public:
  Pokemon();
  string getType(int);
  string getPokeName(int);
    
};
#endif