



CREATE DATABASE csci3308exam;

CREATE TABLE movies(         
    id integer, 
    movie_title text, 
    review text,
    review_date timestamp,
    PRIMARY KEY(id));