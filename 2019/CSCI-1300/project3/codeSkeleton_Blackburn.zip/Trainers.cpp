#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
#include "Trainers.h"


Trainers:: Trainers(){
    trainerGym = "";
    trainerName = "";
}

Trainers:: Trainers(string newtrainergym, string newtrainername){
    trainerGym = newtrainergym;
    trainerName = newtrainername;
}

string Trainers:: getTrainerGym(){
    return trainerGym;
}

string Trainers:: getTrainerName(){
    return trainerName;
}

void Trainers:: setTrainerGym(string newGym){
    trainerGym = newGym;
}

void Trainers:: setTrainerName(string newName){
    trainerName = newName;
}

